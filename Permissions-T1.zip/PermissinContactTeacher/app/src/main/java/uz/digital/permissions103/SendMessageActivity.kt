package uz.digital.permissions103

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import uz.digital.permissions103.model.Contact

class SendMessageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send_message)

        val name: TextView = findViewById(R.id.textName)
        val number: TextView = findViewById(R.id.textNumber)
        val edit: EditText = findViewById(R.id.editMessage)
        val btn: MaterialButton = findViewById(R.id.btnSend)
        val contact = intent.getParcelableExtra<Contact>("contact")
        name.text = contact?.name
        number.text = contact?.number
        btn.setOnClickListener {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(number.text.toString(),null,edit.text.toString().trim(),null,null)
            Toast.makeText(this, "Sms was send successfully", Toast.LENGTH_SHORT).show()
        }

    }
}